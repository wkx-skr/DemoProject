enum Downloading {
  Nothing,
  Selected,
  All,
}
export default Downloading
